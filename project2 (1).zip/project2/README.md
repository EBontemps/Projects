# CPTR 142: Project 2: Calculator

## Project Description

For this project you will write a calculator that can perform at least the four basic math operations (+, -, *, and /). The calculator should accept floating point and negative numbers and support at least nine digits of precision. 

### Input Methods

While you may choose among [several](https://en.wikipedia.org/wiki/Calculator_input_methods) types of calculator input methods, I believe you will find [Reverse Polish Notation (RPN)](https://en.wikipedia.org/wiki/Reverse_Polish_notation) (or postfix) easiest to implement (partly because you don't have to worry about precedence or parenthesis). If you choose the algebraic entry system (or infix), then you should handle precedence (multiplication and division before addition and subtraction) for a top score (while parenthesis would be nice, they don't earn any extra credit).

### Parsing User Input

The user's input will include characters (operators) and numbers. You will probably need to read the line as a string and then convert it to a number if appropriate. This can be done manually (each additional digit causes the previous to be multiplied by 10 till you reach a decimal, and then things change) or you can use the [sscanf()](http://www.cplusplus.com/reference/cstdio/sscanf/) function. 