## Project 2: Calculator

## Date: 3/13/19

## Grade: E

## Comments: Very nice, simple implementation