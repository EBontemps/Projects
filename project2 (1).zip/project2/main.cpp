#include <iostream>
#include <string>
#include "calculator.h"

using namespace std;

int main() {
    
    string expr;
    char menuOption = 'l';
    bool isValid = false;
         
        do{
            cout << "Hello, Welcome to the Reverse Polish Notation Calculator" << endl;
            cout << "Enter the problem you want: ";
            getline(cin, expr);
            cout << "Result: " << RPN(expr) << endl;
            
            do {
                cout << "Do you want to quit or restart(Q or R)?: ";
                cin >> menuOption;
                switch(menuOption) {
                case 'R':
                    isValid = true;
                    cin.clear();
                    cin.ignore(1000, '\n');
                    break;
                case 'Q':
                    return 0;
                default:
                    cin.clear();
                    cin.ignore(1000, '\n');
                    isValid = false;
                    cerr << "Not a correct character, please try again." << endl;
                }
            } while(!isValid);
        } while (true);
        
        return 0;
}