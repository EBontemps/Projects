#ifndef FUNCTIONS_H
#define FUNCTIONS_H
#include <string>
#include <iostream>
using namespace std;

double RPN(string problem);

void Add(float value);

float Delete();

bool isOP(char op);

#endif