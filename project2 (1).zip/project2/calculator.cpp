#include <iostream>
#include <string>
#include <vector>
#include <sstream>
#include <stack> //found this to be better than other methods with the RPN Calculator
#include "calculator.h"
using namespace std;

#define MAX_STACK 100
float _stack[MAX_STACK];
int increment = 0;

void Add(float value) {
     increment++;
    _stack[increment] = value;
}

float Answer() {
    float t = _stack[increment];
    increment--;
    return t;
}

//Operator checks
bool IsOp(char op) {
    switch(op) {
        case '+':
        case '-':
        case '*':
        case '/':
            return true;
        default:
            return false;
    }
}

//calculates result
double RPN(string expression) {
    //variables
    int i = 0;
    float v1, v2, result;
    v1 = result = v2 = 0.0; 
    string temp = "";
    
    while (i < expression.length()) {
        //skips excess white spaces
        while (isspace(expression[i])) {
            i++;
        }
        
        //checks digits and periods
        if(isdigit(expression[i]) | expression[i] == '.' ) {
            while(isdigit(expression[i]) | expression[i] == '.') {
                temp += expression[i];
                i++;
            }
            //functions pushes the stack number
            Add(atof(temp.c_str()));
            temp = "";
        }
        else if (IsOp(expression[i])) {
            if (expression[i] == '+') {
                v1 = Answer();
                v2 = Answer();
                result = v1 + v2;
               
            }
            if (expression[i] == '-'){
                v1 = Answer();
                v2 = Answer();
                result = v2 - v1;
            }
            if (expression[i] == '*'){
                v1 = Answer();
                v2 = Answer();
                result= (v2 * v1);
            }
            if (expression[i] == '/'){
                v1 = Answer();
                v2 = Answer();
                result = (v2 / v1);
            }
            i++;
            cout << "Result: " << result << endl;
            Add(result);
        } else {
            cout << "Invalid Expression." << endl;
            break;
        }
    }
    return Answer();
}